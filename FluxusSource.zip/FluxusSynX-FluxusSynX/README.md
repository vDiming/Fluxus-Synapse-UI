# Didn't want to make it open source, but I had to.
# Join my discord https://discord.gg/FMf2u4SpAn